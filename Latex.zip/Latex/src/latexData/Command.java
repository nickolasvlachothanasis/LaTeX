package latexData;

public interface Command {
    void execute();
}
