package latexTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import gui.LatexEditorView;
import latexData.addLatexCommand;

class AddLatexCommandTest {

	@Test
	void beginEnumerateCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("begin{enumerate}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\begin{enumerate}");
	}
	@Test
	void beginFigureCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("begin{figure}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\begin{figure}");
	}
	@Test
	void beginItemizeCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("begin{itemize}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\begin{itemize}");
	}
	@Test
	void beginTableCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("begin{table}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\begin{table}");
	}
	@Test
	void beginTabularCCCCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("begin{tabular}{|c|c|c|}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\begin{tabular}{|c|c|c|}");
	}
	@Test
	void captionLabelCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("caption{...}\\\\label{...}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\caption{....}\\label{...}");
	}
	@Test
	void chapterCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("chapter");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\chapter{...}");
	}
	@Test
	void endEnumerateCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("end{enumerate}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\end{enumerate} ");
	}
	@Test
	void endFigureCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("end{figure}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\end{figure}");
	}

	@Test
	void endTableCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("end{table}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\end{table}");
	}
	@Test
	void endTabularCommandTest(){
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("end{tabular}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\end{tabular}");
	}
	@Test
	void hlineCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("hline");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\ hline");
	}
	@Test
	void includegraphicsWidthHeightCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("inlcudegraphics[width, height]{...}");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\includegraphics[width=...,height=...]{...}");
	}
	@Test
	void itemCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("item");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\item ...");
	}
	@Test
	void sectionCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("section");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\section{}");
	}
	@Test
	void subsectionCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("subsection");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\subsection{} ");
	}
	@Test
	void subsubsectionCommandTest() {
		LatexEditorView tsiouGui = new LatexEditorView();
		tsiouGui.setCommandToLoad("subsubsection");
		addLatexCommand alc = new addLatexCommand(tsiouGui);
		alc.execute();
		assertEquals(tsiouGui.getTextArea().getText(), "\\subsubsection{}");
	}

}
